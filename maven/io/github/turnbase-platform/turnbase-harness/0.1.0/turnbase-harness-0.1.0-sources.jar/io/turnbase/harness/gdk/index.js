// src/main/ts/client.ts
var TurnBaseClient = class {
  parentOriginOverride;
  parentOrigin = null;
  started = false;
  disposed = false;
  initReceived = false;
  onMessage = (event) => {
    this.handleMessage(event);
  };
  initCallback = null;
  gameEventCallback = null;
  playerJoinedCallback = null;
  playerLeftCallback = null;
  gameOverCallback = null;
  constructor(options) {
    this.parentOriginOverride = options?.parentOrigin;
  }
  /** Register the `init` handler (§4, §5). Replaces any prior handler. */
  onInit(cb) {
    this.initCallback = cb;
    return this;
  }
  /** Register the `game_event` handler (§10). Replaces any prior handler. */
  onGameEvent(cb) {
    this.gameEventCallback = cb;
    return this;
  }
  /** Register the `player_joined` handler (§10). Replaces any prior handler. */
  onPlayerJoined(cb) {
    this.playerJoinedCallback = cb;
    return this;
  }
  /** Register the `player_left` handler (§10). Replaces any prior handler. */
  onPlayerLeft(cb) {
    this.playerLeftCallback = cb;
    return this;
  }
  /** Register the `game_over` handler (§10). Replaces any prior handler. */
  onGameOver(cb) {
    this.gameOverCallback = cb;
    return this;
  }
  /**
   * Begin listening and announce readiness to the platform (§4). Safe to call once; subsequent
   * calls are no-ops. Throws synchronously when `window.__TURNBASE__` is missing and no
   * `parentOrigin` override was supplied — the game cannot run untrusted.
   */
  start() {
    if (this.started) {
      return;
    }
    const parentOrigin = this.parentOriginOverride ?? window.__TURNBASE__?.parentOrigin;
    if (!parentOrigin) {
      throw new Error(
        "TurnBaseClient.start(): window.__TURNBASE__ is missing or malformed and no parentOrigin override was supplied"
      );
    }
    this.started = true;
    this.parentOrigin = parentOrigin;
    window.addEventListener("message", this.onMessage);
    this.post({ type: "ready" });
  }
  /**
   * Send a player action to the platform (FR-FEGDK-003, FR-FA-001). Valid only after the `init`
   * event has been delivered.
   */
  sendAction(payload) {
    if (!this.initReceived) {
      throw new Error("TurnBaseClient.sendAction(): called before the init event was delivered");
    }
    this.post({ type: "action", payload });
  }
  /** Remove the message listener and stop the client. Idempotent. */
  dispose() {
    if (this.disposed) {
      return;
    }
    this.disposed = true;
    window.removeEventListener("message", this.onMessage);
  }
  post(message) {
    const parent = window.parent;
    if (!this.parentOrigin || !parent || parent === window) {
      return;
    }
    parent.postMessage(message, this.parentOrigin);
  }
  handleMessage(event) {
    if (event.origin !== this.parentOrigin || event.source !== window.parent) {
      return;
    }
    const data = event.data;
    if (!data || typeof data !== "object" || typeof data.type !== "string") {
      return;
    }
    switch (data.type) {
      case "init":
        this.initReceived = true;
        this.initCallback?.({
          role: data.role,
          self: data.self,
          roster: data.roster,
          teams: data.teams,
          sessionId: data.sessionId
        });
        return;
      case "game_event":
        this.gameEventCallback?.(data.payload);
        return;
      case "player_joined":
        this.playerJoinedCallback?.(data.player);
        return;
      case "player_left":
        this.playerLeftCallback?.(data.player);
        return;
      case "game_over":
        this.gameOverCallback?.(data.results);
        return;
      default:
        return;
    }
  }
};
export {
  TurnBaseClient
};
//# sourceMappingURL=index.js.map